import sys
import os
import math
import glob
import matplotlib
import matplotlib.pyplot

class PlotDumpFields(object):
    def __init__(self, output_dir, file_name, is_em_field = False):
        """
        Initialise the Plotting routines ready for loading
        - output_dir: directory where file is stored and that will be used for 
        output
        - file_name: name of the file (relative to output_dir)
        - is_em_field: set to True if using DumpEMFields with coordinate_system 
        cylindrical. Set to False if using DumpFields.
        """
        if is_em_field:
            self.keys = ["r", "phi", "z", "t", "br", "bphi", "bz", "er", "ephi", "ez"]
        else:
            self.keys = ["x", "y", "z", "bx", "by", "bz"]
        self.units = {"bx":0.1, "by":0.1, "bz":0.1, "br":0.1, "bphi":0.1, "bz":0.1}
        self.n_lines = 0
        self.output_dir = output_dir
        self.file_name = os.path.join(output_dir, file_name)
        self.field_map = {}
        self.field_grid = {}

    def plot_1d(self, cuts, ax1, ax2, suffix):
        """
        Plot a slice through the field map
        - cuts: a dictionary mapping the parameter to the slice value
        - ax1: variable from self.keys to plot on the x-axis
        - ax2: variable from self.keys to plot on the y-axis
        - suffix: string suffix to add to the end of the file name
        """
        value1, value2 = [], []
        n_points = len(list(self.field_map.values())[0])
        for i in range(n_points):
            is_cut = False
            for cut_key, cut_value in cuts.items():
                if abs(self.field_map[cut_key][i] - cut_value) > 1e-3:
                    is_cut = True
            if is_cut:
                continue
            value1.append(self.field_map[ax1][i])
            value2.append(self.field_map[ax2][i])
        figure = matplotlib.pyplot.figure()
        axes = figure.add_subplot(1, 1, 1)
        axes.plot(value1, value2)
        axes.set_xlabel(self.name_dict[ax1])
        axes.set_ylabel(self.name_dict[ax2])
        axes.set_title("OPAL FFA example 3")
        name = os.path.join(self.output_dir, ax1+"_vs_"+ax2+"_"+suffix+".png")
        figure.savefig(name)

    def calculate_cylindrical_fields(self):
        """
        Calculate cartesian coordinates to cylindrical coordinates
        """
        n_points = len(self.field_map['bx'])
        self.field_map['bphi'] = [None]*n_points
        self.field_map['br'] = [None]*n_points
        for i in range(n_points):
            x = self.field_map['x'][i]
            y = self.field_map['y'][i]
            bx = self.field_map['bx'][i]
            by = self.field_map['by'][i]
            phi = math.atan2(y, x)
            br = bx*math.cos(phi) + by*math.sin(phi)
            bphi = -bx*math.sin(phi) + by*math.cos(phi)
            self.field_map['br'][i] = br
            self.field_map['bphi'][i] = bphi

    def calculate_cartesian_fields(self):
        """
        Calculate from cylindrical coordinates from cartesian coordinates
        """
        n_points = len(self.field_map['br'])
        self.field_map['bx'] = [None]*n_points
        self.field_map['by'] = [None]*n_points
        for i in range(n_points):
            phi = self.field_map['phi'][i]*math.pi/180.
            bphi = self.field_map['bphi'][i]
            br = self.field_map['br'][i]
            bx = br*math.cos(phi) - bphi*math.sin(phi)
            by = bphi*math.cos(phi) + br*math.sin(phi)
            self.field_map['bx'][i] = bx
            self.field_map['by'][i] = by

    def load_dump_fields(self):
        """
        Load the field maps from file; load the corresponding field values and
        calculate field components that are not in the file.
        """
        print("Loading", self.file_name)
        fin = open(self.file_name)
        header_lines = len(self.keys)+2
        for i in range(header_lines):
            fin.readline()
        for key in self.keys:
            self.field_map[key] = []
        units_ = [1. for key in self.keys]
        for i, key in enumerate(self.keys):
            if key in self.units:
                units_[i] = self.units[key]
        for self.n_lines, line in enumerate(fin.readlines()):
            try:
                data = [float(word) for word in line.split()]
                for i, key in enumerate(self.keys):
                    self.field_map[key].append(data[i]*units_[i])
            except (ValueError, IndexError):
                print(line[:-1])
                continue
        if 'phi' in list(self.field_map.keys()):
            self.calculate_cartesian_fields()
        if 'x' in list(self.field_map.keys()):
            self.calculate_cylindrical_fields()

    root_objects = []
    name_dict = {"phi":"$\\phi$ [degree]", "t":"t [ns]",
                 "r":"r [m]", "x":"x [m]", "y":"y [m]", "z":"z [m]",
                 "ephi":"E$_{\\phi}$ [MV/m]"}

def main(a_dir):
    """
    Plot the azimuthal electric field map; then plot the time dependent fields.
    Note how the RF frequency increases with time as the particles gain energy.
    """
    is_em_field = True
    rf_list = []
    time, frequency = [], []
    plotter = PlotDumpFields(a_dir, "FieldMapAzimuthal.dat", is_em_field)
    plotter.load_dump_fields()
    plotter.plot_1d({"r":4.}, "phi", "ephi", "0")
    for i in range(1, 7):
        file_name = "FieldMapRf"+str(i)+".dat"
        plotter = PlotDumpFields(a_dir, file_name, is_em_field)
        plotter.load_dump_fields()
        plotter.plot_1d({"r":4.}, "t", "ephi", str(i))
        #rf_list.append(plotter.sine_fit())
    for item in rf_list:
        print(item)
    return rf_list

if __name__ == "__main__":
    if len(sys.argv) < 2  or not os.path.isdir(sys.argv[1]):
        print("Usage: 'python plot_dump_fields path/to/target/directory'")
    else:
        target_directory = sys.argv[1]
        main(sys.argv[1])
    matplotlib.pyplot.show(block=False)
    input("Ran okay - press <Enter> to end")

