rm FieldMap*
rm PROBE*
rm SectorFFAGMagnet-*
rm SectorFFAGMagnet.*
rm timing.dat

