rm FieldMap*
rm PROBE*
rm SectorFFAMagnet-*
rm SectorFFAMagnet.*
rm timing.dat
rm *.loss
rmdir data
