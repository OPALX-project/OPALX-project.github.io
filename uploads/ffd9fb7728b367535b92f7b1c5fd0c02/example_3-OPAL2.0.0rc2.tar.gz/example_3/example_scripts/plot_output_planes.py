#This file is a part of xboa
#
#xboa is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#
#xboa is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with xboa in the doc folder.  If not, see 
#<http://www.gnu.org/licenses/>.

"""
\namespace _opal_tracking
"""

import time
import tempfile
import subprocess
import os
import glob
import math
import sys

import ROOT

class PlotLossFiles(object):
    """Plot output from PROBE?.loss files"""
    def __init__(self, output_file_glob):
        """
        Initialise the plotter ready to laod data
        * output_file_glob: string with file to be read. If wildcards are
        included (*, ?) then we can load more than one file.
        """
        self.output_name = output_file_glob
        self.ref = {"pid":2212, "mass":938.2720813, "charge":1.}
        self.hit_list = []

    def plot_one(self, event, x_axis, y_axis, canvas=None, color=ROOT.kBlack):
        """
        Plot particle variables based on x_axis, y_axis.
        * event: integer id of the event to be plotted
        * x_axis: string corresponding to the x-axis variable
        * y_axis: string corresponding to the y-axis variable
        """
        x_values = []
        y_values = []
        name = x_axis+" vs "+y_axis
        draw_options = "P SAME"
        if canvas == None:
            canvas = ROOT.TCanvas(name, name)
            self.root_objects.append(canvas)
            canvas.Draw()
            draw_options = "AP"
        canvas.cd()
        graph = ROOT.TGraph()
        self.root_objects.append(graph)
        for i, hit in enumerate(self.hit_list):
            if hit["event_number"] != event:
                continue
            graph.SetPoint(i, hit[x_axis], hit[y_axis])
        graph.SetMarkerColor(color)
        graph.SetMarkerStyle(7)
        graph.Draw(draw_options)
        graph.GetXaxis().SetTitle(self.axis_label[x_axis])
        graph.GetYaxis().SetTitle(self.axis_label[y_axis])
        canvas.Print(name.replace(" ", "_")+".png")
        return canvas

    def read_probes(self):
        """
        glob the output file name; read in data in the files and store in
        memory (with many particles this can use lots of memory!)
        """
        print "Loading files"
        file_list = glob.glob(self.output_name)
        fin_list = [open(file_name) for file_name in file_list]
        line = "0"
        line_number = 0
        while line != "" and len(fin_list) > 0:
            for fin in fin_list: 
                line = fin.readline()
                if line == "":
                    break
                try:
                    self.hit_list.append(self.read_one_line(line, line_number))
                except ValueError:
                   pass
                line_number += 1
   
    def read_one_line(self, line, station): 
        """
        Read one line of the probe file
        """
        words = line.split()
        hit_dict = {}
        for key in "pid", "mass", "charge":
            hit_dict[key] = self.ref[key]
        for i, key in enumerate(["x", "z", "y"]):
            hit_dict[key] = float(words[i+1])
        for i, key in enumerate(["px", "pz", "py"]):
            hit_dict[key] = float(words[i+4])*self.ref["mass"]
        event = int(words[7])
        hit_dict["event_number"] = int(words[7])
        hit_dict["station"] = station
        x = hit_dict["x"]
        y = hit_dict["z"]
        px = hit_dict["px"]
        py = hit_dict["pz"]
        phi = math.atan2(y, x)
        hit_dict["t"] = float(words[9])
        hit_dict["x"] = + x*math.cos(phi) + y*math.sin(phi)
        hit_dict["z"] = - x*math.sin(phi) + y*math.cos(phi)
        hit_dict["px"] = + px*math.cos(phi) + py*math.sin(phi) # momentum in the radial direction
        # go through file line by line reading hit data
        hit_dict["pz"] = - px*math.sin(phi) + py*math.cos(phi) # momentum in the azimuthal direction
        hit_dict["energy"] = (px**2+py**2+self.ref["mass"]**2)**0.5-self.ref["mass"]
        return hit_dict

    axis_label = {"t":"t [ns]", "energy":"Energy [MeV]", "pr":"p_{r} [MeV/c]",
                  "pz":"p_{#phi} [MeV/c]", "x":"r [mm]", "z":"s [mm]"}
    root_objects = []

def main(a_dir):
    """
    Load a sample loss file and plot time vs energy
    """
    plotter = PlotLossFiles(a_dir+"/PROBE1.loss")
    plotter.read_probes()
    canvas = plotter.plot_one(1, "t", "energy")
    plotter.plot_one(0, "t", "energy", canvas, ROOT.kGreen)
    plotter.plot_one(2, "t", "energy", canvas, ROOT.kBlue)


if __name__ == "__main__":
    if len(sys.argv) < 2  or not os.path.isdir(sys.argv[1]):
        print "Usage: 'python plot_output_planes path/to/target/directory'"
    else:
        print "Plotting PROBE output"
        target_directory = sys.argv[1]
        main(sys.argv[1])
    raw_input("Ran okay - press <Enter> to end")

