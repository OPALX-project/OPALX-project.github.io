import sys
import os
import math
try:
    import matplotlib
except ImportError:
    print("I couldn't find matplotlib - please check your matplotlib installation.")

class PlotDumpFields(object):
    def __init__(self, file_name, is_em_field = False):
        if is_em_field:
            self.keys = ["r", "phi", "z", "t", "br", "bphi", "bz", "er", "ephi", "ez"]
        else:
            self.keys = ["x", "y", "z", "bx", "by", "bz"]
        self.units = {"bx":0.1, "by":0.1, "bz":0.1, "br":0.1, "bphi":0.1, "bz":0.1}
        self.n_lines = 0
        self.file_name = file_name
        self.field_map = {}
        self.field_grid = {}
        
    def plot(self):
        self.load_dump_fields()
        if "r" in self.keys:
            canvas_xy = self.plot_dump_fields("phi", "r", "bz")
        else:
            canvas_xy = self.plot_dump_fields("x", "y", "bz")
        return canvas_xy

    def plot_1d(self, cuts, ax1, ax2):
        value1, value2 = [], []
        n_points = len(self.field_map['by'])
        for i in range(n_points):
            is_cut = False
            for cut_key, cut_value in cuts.items():
                if abs(self.field_map[cut_key][i] - cut_value) > 1e-3:
                    is_cut = True
            if is_cut:
                continue
            value1.append(self.field_map[ax1][i])
            value2.append(self.field_map[ax2][i])
        canvas_1d = ROOT.TCanvas(ax1+" vs "+ax2, ax1+" vs "+ax2)
        axis_1 = self.name_dict[ax1]
        axis_2 = self.name_dict[ax2]
        hist = ROOT.TH2D(ax1+" vs "+ax2, ";"+axis_1+";"+axis_2,
                         1000, min(value1), max(value1),
                         1000, min(value2), max(value2))
        hist.SetStats(False)
        graph = ROOT.TGraph(len(value1))
        graph.SetLineWidth(2)
        for i, x in enumerate(value1):
            y = value2[i]
            graph.SetPoint(i, x, y)
        hist.Draw()
        graph.Draw("SAMEL")
        canvas_1d.Update()
        self.root_objects.append(canvas_1d)
        self.root_objects.append(hist)
        self.root_objects.append(graph)
        return canvas_1d

    def calculate_cylindrical_fields(self):
        n_points = len(self.field_map['bx'])
        self.field_map['bphi'] = [None]*n_points
        self.field_map['br'] = [None]*n_points
        self.field_map['btot'] = [None]*n_points
        for i in range(n_points):
            x = self.field_map['x'][i]
            y = self.field_map['y'][i]
            bx = self.field_map['bx'][i]
            by = self.field_map['by'][i]
            bz = self.field_map['bz'][i]
            btot = (bx**2+by**2+bz**2)**0.5
            phi = math.atan2(y, x)
            br = bx*math.cos(phi) + by*math.sin(phi)
            bphi = -bx*math.sin(phi) + by*math.cos(phi)
            self.field_map['br'][i] = br
            self.field_map['bphi'][i] = bphi
            self.field_map['btot'][i] = btot

    def calculate_cartesian_fields(self):
        n_points = len(self.field_map['br'])
        self.field_map['bx'] = [None]*n_points
        self.field_map['by'] = [None]*n_points
        self.field_map['btot'] = [None]*n_points
        for i in range(n_points):
            phi = self.field_map['phi'][i]*math.pi/180.
            bphi = self.field_map['bphi'][i]
            br = self.field_map['br'][i]
            bz = self.field_map['bz'][i]
            bx = br*math.cos(phi) - bphi*math.sin(phi)
            by = bphi*math.cos(phi) + br*math.sin(phi)
            btot = (br**2+bphi**2+bz**2)**0.5
            self.field_map['phi'][i] *= 1.
            self.field_map['bx'][i] = bx
            self.field_map['by'][i] = by
            self.field_map['btot'][i] = btot

    def load_dump_fields(self):
        print("Loading", self.file_name)
        fin = open(self.file_name)
        header_lines = len(self.keys)+2
        for i in range(header_lines):
            fin.readline()
        for key in self.keys:
            self.field_map[key] = []
        units_ = [1. for key in self.keys]
        for i, key in enumerate(self.keys):
            if key in self.units:
                units_[i] = self.units[key]
        for self.n_lines, line in enumerate(fin.readlines()):
            try:
                data = [float(word) for word in line.split()]
                for i, key in enumerate(self.keys):
                    self.field_map[key].append(data[i]*units_[i])
            except (ValueError, IndexError):
                print(line[:-1])
                continue
        if 'phi' in list(self.field_map.keys()):
            self.calculate_cartesian_fields()
        if 'x' in list(self.field_map.keys()):
            self.calculate_cylindrical_fields()

    def get_bin_list(self, key):
        data = self.field_map[key]
        bin_list = [round(datum, 4) for datum in data]
        bin_list = list(set(bin_list)) # force elements to be unique
        bin_list = sorted(bin_list)
        if len(bin_list) == 0:
            raise RuntimeError("No data")
        elif len(bin_list) == 1:
            bin_min = bin_list[0] - 1
            bin_max = bin_list[0] + 1
            n_bins = 1
        else:
            bin_step = bin_list[1] - bin_list[0]
            bin_min = bin_list[0]-bin_step/2.
            bin_max = bin_list[-1]+bin_step/2.
            n_bins = len(bin_list)
        return bin_min, bin_max, n_bins

    def plot_dump_fields(self, var_1, var_2, var_3):
        axes = self.check_and_build_axes(None)
        min_1, max_1, n_1 = self.get_bin_list(var_1)
        min_2, max_2, n_2 = self.get_bin_list(var_2)
        min_field = min(self.field_map[var_3])
        max_field = max(self.field_map[var_3])
        if min_field < 0:
            abs_max_field = max(max_field, abs(min_field))
            field_norm = matplotlib.colors.Normalize(-abs_max_field, abs_max_field, False)
            cmap_ = "bwr"
        else:
            field_norm = matplotlib.colors.Normalize(0, max_field, False)
            cmap_ = "Reds"
        hist = axes.hist2d(self.field_map[var_1], 
                           self.field_map[var_2], 
                           weights=self.field_map[var_3],
                           bins=[n_1, n_2],
                           range=[[min_1, max_1], [min_2, max_2]],
                           cmap=cmap_,
                           norm=field_norm)
        axes.set_xlabel(self.name_dict[var_1])
        axes.set_ylabel(self.name_dict[var_2])
        axes.set_title("OPAL FFA Example 4")
        axes.get_figure().colorbar(hist[3], label=self.name_dict[var_3])
        return axes

    @classmethod
    def check_and_build_axes(cls, axes):
        if axes == None:
            figure = matplotlib.pyplot.figure()
            axes =  figure.add_subplot(1, 1, 1)
            cls.figure = figure
        return axes

    figure = None

    name_dict = {"phi":"$\\phi$ [degree]", "r":"r [m]", "x":"x [m]", "y":"y [m]", "z":"z [m]",
                 "bx":"B_{x} [T]", "by":"B_{y} [T]", "bz":"B$_{z}$ [T]", "btot":"B$_{tot}$ [T]"}
