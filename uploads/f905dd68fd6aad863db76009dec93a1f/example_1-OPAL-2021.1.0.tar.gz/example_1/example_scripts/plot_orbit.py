"""
Plot a single OPAL closed orbit (once tracking has finished)

Loads the output from OPAL single particle tracking record and plots the 
resultant trajectory, either in cylindrical or cartesian coordinates. Calls
routines from plot_dump_fields.py to plot magnetic fields, then plots 
trajectories over the top.
"""

import sys
if sys.version_info.major < 3:
    print("Require python3 to run this example")
    sys.exit()
import os
import copy
import math
import plot_dump_fields

try:
    import matplotlib
    import matplotlib.pyplot
except ImportError:
    print("I couldn't find matplotlib - please check your matplotlib installation.")

def r_phi_track_file(data):
    """
    Calculate trajectory in cylindrical coordinates based on cartesian track
    information.
    - data: the data loaded from a track file
    """
    data = copy.deepcopy(data)
    data["r"] = list(range(len(data["x"])))
    data["phi"] = list(range(len(data["x"])))
    for i in range(len(data["r"])):
        data["r"][i] = (data["x"][i]**2+data["y"][i]**2.)**0.5
        data["phi"][i] = math.degrees(math.atan2(data["y"][i], data["x"][i]))
    return data

def parse_file(file_name, heading, types, skiplines):
    """
    Open a column-sorted file and load the data.
    - file_name: string name of the file
    - heading: list containing string names, one for each column of data
    - types: list containing the type, one for each column of data
    - skiplines: number of lines to skip (e.g. header lines)
    Returns track data
    """
    if len(heading) != len(types):
        raise KeyError("Heading mismatched to types in parse_file "+file_name)
    fin = open(file_name)
    for i in range(skiplines):
        line = fin.readline()
    data = {}
    for item in heading:
        data[item] = []
    line = fin.readline()[:-1]
    while line != "":
        words = line.split()
        if len(words) != len(heading):
            print("Line\n  "+line+"\nmismatched to heading\n  "+str(heading)+"\nin parse_file "+file_name)
        else:
            words = [types[i](x) for i, x in enumerate(words)]
            for i, item in enumerate(heading):
                data[item].append(words[i])
        line = fin.readline()[:-1]
    print("Got data from file "+file_name)
    return data

def parse_track_file(filename):
    """
    Parse the OPAL *-trackOrbit.dat file
    - filename: string file name
    Opens the OPAL file and loads in data using parse_file. Uses 
    r_phi_track_file to calculate track data in cylindrical coordinates. Returns
    a dict, that maps data name (x, y, etc) to a list of those data. Each data 
    list has the same length, which is the number of track points in the track 
    data file.
    """
    file_name = filename
    heading = ["id", "x", "px", "y", "py", "z", "pz"]
    types = [str]+[float]*(len(heading)-1)
    data = parse_file(file_name, heading, types, 1)
    data = r_phi_track_file(data)
    return data

def check_and_build_axes(axes):
    """
    If axes is None, build and returns a new set of matplotlib axes
    """
    return plot_dump_fields.PlotDumpFields.check_and_build_axes(axes)

def plot_x_y_projection(step_list, axes = None):
    """
    Plot the projection of the data onto x, y, which are the horizontal 
    coordinates.
    - step_list: track point data returned by parse_track_file
    - axes: matplotlib axes used for plotting. If None, a new set of axes are
    generated.
    Returns the axes used for plotting
    """
    axes = check_and_build_axes(axes)
    axes.plot(step_list["x"], step_list["y"])
    return axes

def plot_phi_r_projection(step_list, axes = None):
    """
    Plot the projection of the data onto phi, r which is the azimuthal angle
    and distance from the FFA centre.
    - step_list: track point data returned by parse_track_file
    - axes: matplotlib axes used for plotting. If None, a new set of axes are
    generated.
    Returns the axes used for plotting
    """
    axes = check_and_build_axes(axes)
    points = list(zip(step_list["phi"], step_list["r"]))
    points = sorted(points)
    points = list(zip(*tuple(points)))
    axes.plot(points[0], points[1])
    return axes

def plot_beam_pipe(inner_radius, outer_radius, n_periods, axes=None):
    """
    Plot some tramlines as guidance, showing cell structure and nominal inner 
    and outer field radius.
    - inner_radius: Inner radius of the plotted beam pipe
    - outer_radius: Outer radius of the plotted beam pipe
    - n_periods: number of periods in the ring. A radial "spoke" is drawn for 
    each period
    - axes: matplotlib axes used for plotting. If None, a new set of axes are
    generated.
    Returns the axes used for plotting
    """
    n_steps = 361 # number of azimuthal steps
    color = 'black'
    width = 0.5

    axes = check_and_build_axes(axes)
    inner_x = [inner_radius*math.sin(i/float(n_steps-1)*2.*math.pi) \
                                                        for i in range(n_steps)]
    inner_y = [inner_radius*math.cos(i/float(n_steps-1)*2.*math.pi) \
                                                        for i in range(n_steps)]
    axes.plot(inner_x, inner_y, color=color, linewidth=width)

    outer_x = [outer_radius*math.sin(i/float(n_steps-1)*2.*math.pi) \
                                                        for i in range(n_steps)]
    outer_y = [outer_radius*math.cos(i/float(n_steps-1)*2.*math.pi) \
                                                        for i in range(n_steps)]
    axes.plot(outer_x, outer_y, color=color, linewidth=width)
    for i in range(n_periods):
        spoke_x = [inner_radius*math.sin(i/float(n_periods)*2.*math.pi),
                    outer_radius*math.sin(i/float(n_periods)*2.*math.pi)]
        spoke_y = [inner_radius*math.cos(i/float(n_periods)*2.*math.pi),
                    outer_radius*math.cos(i/float(n_periods)*2.*math.pi)]
        axes.plot(spoke_x, spoke_y, color=color, linewidth=width)
    return axes

def plot_cylindrical(output_dir, opal_run_dir, step_list):
    """
    Plot a selection of data in cylindrical polar coordinates
    - output_dir: output directory where the plots are written
    - opal_run_dir: run directory where the field maps are stored
    - step_list: list of track points
    """
    field_plot = plot_dump_fields.PlotDumpFields(opal_run_dir+"/data/FieldMapRPHI.dat", True)
    field_plot.load_dump_fields()
    
    axes = field_plot.plot_dump_fields("phi", "r", "bz")
    plot_phi_r_projection(step_list, axes)
    plot_file = os.path.join(output_dir, "opal_example_1_phi_r_bz.png")
    plot_dump_fields.PlotDumpFields.figure.savefig(plot_file)

    axes = field_plot.plot_dump_fields("phi", "r", "btot")
    plot_phi_r_projection(step_list, axes)
    plot_file = os.path.join(output_dir, "opal_example_1_phi_r_btot.png")
    plot_dump_fields.PlotDumpFields.figure.savefig(plot_file)

def plot_cartesian(output_dir, opal_run_dir, step_list):
    """
    Plot a selection of data in cartesian coordinates
    - output_dir: output directory where the plots are written
    - opal_run_dir: run directory where the field maps are stored
    - step_list: list of track points
    """
    field_plot = plot_dump_fields.PlotDumpFields(opal_run_dir+"/data/FieldMapXY.dat")
    field_plot.load_dump_fields()

    axes = field_plot.plot_dump_fields("x", "y", "bz")
    axes = plot_x_y_projection(step_list, axes)
    plot_beam_pipe(2.7, 3.5, 12, axes)
    plot_file = os.path.join(output_dir, "opal_example_1_x_y_bz.png")
    plot_dump_fields.PlotDumpFields.figure.savefig(plot_file)

    axes = field_plot.plot_dump_fields("x", "y", "btot")
    axes = plot_x_y_projection(step_list, axes)
    plot_beam_pipe(2.7, 3.5, 12, axes)
    plot_file = os.path.join(output_dir, "opal_example_1_x_y_btot.png")
    plot_dump_fields.PlotDumpFields.figure.savefig(plot_file)

def main(output_dir, run_dir, run_file):
    """
    Load OPAL track orbit data and make a selection of plots of trajectories and
    fields.
    """
    output_dir += "/"
    opal_run_dir = run_dir
    step_list = parse_track_file(opal_run_dir+run_file)
    try:
        plot_cylindrical(output_dir, opal_run_dir, step_list)
    except Exception:
        sys.excepthook(*sys.exc_info())
    try:
        plot_cartesian(output_dir, opal_run_dir, step_list)
    except Exception:
        sys.excepthook(*sys.exc_info())

if __name__ == "__main__":
    if len(sys.argv) < 2  or not os.path.isdir(sys.argv[1]):
        print("Usage: 'python3 plot_orbit path/to/target/directory'")
        sys.exit()
    target_directory = sys.argv[1]
    main(target_directory, target_directory, "SectorFFAMagnet-trackOrbit.dat")
    matplotlib.pyplot.show(block=False)
    input("Press <Enter> to close")

