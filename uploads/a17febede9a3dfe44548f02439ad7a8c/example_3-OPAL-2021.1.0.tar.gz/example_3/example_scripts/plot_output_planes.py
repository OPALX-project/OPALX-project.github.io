"""
\namespace _opal_tracking
"""

import time
import tempfile
import subprocess
import os
import glob
import math
import sys

import matplotlib
import matplotlib.pyplot

class PlotLossFiles(object):
    """Plot output from PROBE?.loss files"""
    def __init__(self, output_dir, file_glob):
        """
        Initialise the plotter ready to laod data
        * output_file_glob: string with file to be read. If wildcards are
        included (*, ?) then we can load more than one file.
        """
        self.output_dir = output_dir
        self.output_name = os.path.join(output_dir, file_glob)
        self.ref = {"pid":2212, "mass":938.2720813, "charge":1.}
        self.hit_list = []
        self.figure = matplotlib.pyplot.figure()
        self.axes = self.figure.add_subplot(1, 1, 1)

    def plot_one(self, event, x_axis, y_axis, color):
        """
        Plot particle variables based on x_axis, y_axis.
        * event: integer id of the event to be plotted
        * x_axis: string corresponding to the x-axis variable
        * y_axis: string corresponding to the y-axis variable
        """
        x_values = [hit[x_axis] for hit in self.hit_list if \
                                                hit["event_number"] == event]
        y_values = [hit[y_axis] for hit in self.hit_list if \
                                                hit["event_number"] == event]
        name = x_axis+" vs "+y_axis
        self.axes.plot(x_values, y_values)
        self.axes.set_xlabel(self.axis_label[x_axis])
        self.axes.set_ylabel(self.axis_label[y_axis])

    def read_probes(self):
        """
        glob the output file name; read in data in the files and store in
        memory (with many particles this can use lots of memory!)
        """
        print("Loading files")
        file_list = glob.glob(self.output_name)
        fin_list = [open(file_name) for file_name in file_list]
        line = "0"
        line_number = 0
        while line != "" and len(fin_list) > 0:
            for fin in fin_list: 
                line = fin.readline()
                if line == "":
                    break
                try:
                    self.hit_list.append(self.read_one_line(line, line_number))
                except ValueError:
                   print("Line", line)
                line_number += 1
   
    def read_one_line(self, line, station): 
        """
        Read one line of the probe file
        """
        words = line.split()
        hit_dict = {}
        for key in "pid", "mass", "charge":
            hit_dict[key] = self.ref[key]
        for i, key in enumerate(["x", "z", "y"]):
            hit_dict[key] = float(words[i])
        for i, key in enumerate(["px", "pz", "py"]):
            hit_dict[key] = float(words[i+3])*self.ref["mass"]
        event = int(words[7])
        hit_dict["event_number"] = int(words[6])
        hit_dict["station"] = station
        x = hit_dict["x"]
        y = hit_dict["z"]
        px = hit_dict["px"]
        py = hit_dict["pz"]
        phi = math.atan2(y, x)
        hit_dict["t"] = float(words[9])
        hit_dict["r"] = + x*math.cos(phi) + y*math.sin(phi)
        hit_dict["z"] = - x*math.sin(phi) + y*math.cos(phi)
        hit_dict["pr"] = + px*math.cos(phi) + py*math.sin(phi) # momentum in the radial direction
        hit_dict["pphi"] = - px*math.sin(phi) + py*math.cos(phi) # momentum in the azimuthal direction
        hit_dict["energy"] = (px**2+py**2+self.ref["mass"]**2)**0.5-self.ref["mass"]
        return hit_dict

    axis_label = {"t":"t [ns]", "energy":"Energy [MeV]", "pr":"p_{r} [MeV/c]",
                  "pz":"p_{#phi} [MeV/c]", "x":"r [mm]", "z":"s [mm]"}

def main(a_dir):
    """
    Load a sample loss file and plot time vs energy
    """
    plotter = PlotLossFiles(a_dir, "PROBE1.loss")
    plotter.read_probes()
    plotter.plot_one(1, "t", "energy", "black")
    plotter.plot_one(0, "t", "energy", "green")
    plotter.plot_one(2, "t", "energy", "blue")
    plotter.figure.savefig(os.path.join(a_dir, "t_vs_energy.png"))

if __name__ == "__main__":
    if len(sys.argv) < 2  or not os.path.isdir(sys.argv[1]):
        print("Usage: 'python plot_output_planes path/to/target/directory'")
    else:
        print("Plotting PROBE output")
        target_directory = sys.argv[1]
        main(sys.argv[1])
    matplotlib.pyplot.show(block=False)
    input("Ran okay - press <Enter> to end")

